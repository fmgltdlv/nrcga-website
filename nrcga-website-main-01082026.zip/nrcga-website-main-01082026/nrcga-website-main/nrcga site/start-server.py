#!/usr/bin/env python3
"""
Simple HTTP server to serve the NRCGA website locally.
This avoids CORS issues when loading GeoJSON files.

Usage:
    python start-server.py

Then open http://localhost:8000/data-maps.html in your browser
"""

import http.server
import socketserver
import os
import webbrowser
from pathlib import Path

PORT = 8000

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # Add CORS headers to allow loading GeoJSON files
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def log_message(self, format, *args):
        # Suppress default logging
        pass

def main():
    # Change to the script's directory
    os.chdir(Path(__file__).parent)
    
    with socketserver.TCPServer(("", PORT), MyHTTPRequestHandler) as httpd:
        print(f"Server starting on http://localhost:{PORT}")
        print(f"Open http://localhost:{PORT}/data-maps.html in your browser")
        print("Press Ctrl+C to stop the server")
        
        # Optionally open browser automatically
        try:
            webbrowser.open(f'http://localhost:{PORT}/data-maps.html')
        except:
            pass
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")

if __name__ == "__main__":
    main()

